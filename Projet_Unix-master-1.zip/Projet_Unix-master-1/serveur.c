/*
 * ==================================================================
 *
 * Filename : serveur.c
 *
 * Description : file used to play the server role.
 *
 * Author : MANIET Antoine "amaniet152", SACRE Christopher "csacre15"
 *
 * ==================================================================
 */

#include "global.h"
#include "serveur.h"

/*catch signal*/
void time_out(int sig){
	return;
}

int main(int argc, char** argv) {
	SOCKET sock;
	SOCKET csock[MAX_PLAYER];
	message * pseudos[MAX_PLAYER];
	message buffer;


	//flock to avoid double server opening
	int f_lock;
	if ((f_lock = open("serveur.lock", O_RDWR)) == -1){
		perror("open()\n");
		exit(errno);
	}
	if (flock(f_lock, LOCK_EX | LOCK_NB) == -1){
		if( errno == EWOULDBLOCK ){
			printf("The server is already launched\n");
		} else {
			printf("flock()\n");
		}
		exit(errno);
	}

	int port, n = 0, i = 0;
	const char *hostname = "127.0.0.1";
	SOCKADDR_IN sin;
	SOCKADDR_IN csin;
	if(argc != 3) {
		fprintf(stderr, "serveur [numPort] [stderr]\n");
		return EXIT_ERROR;
	}
	port = atoi(*++argv);
	sock = socket(AF_INET, SOCK_STREAM, 0);
	if(sock == INVALID_SOCKET) {
		perror("socket()");
		exit(errno);
	}
	sin.sin_addr.s_addr = htonl(INADDR_ANY);
	sin.sin_family = AF_INET;
	sin.sin_port = htons(port);
	if(bind(sock, (SOCKADDR *) &sin, sizeof sin) == SOCKET_ERROR) {
		if( errno == EADDRINUSE )
		{
			printf("The server is already launched\n");
		} else {
			perror("bind()");
			exit(errno);
		}
	}
	if(listen(sock, MAX_PLAYER) == SOCKET_ERROR) {
		perror("listen()");
		exit(errno);
	}
	int sinsize = sizeof csin;
	while((csock[i] = accept(sock, (SOCKADDR *) &csin, (socklen_t *) &sinsize)) && i < MAX_PLAYER) {
		buffer.status = 200;
		sprintf(buffer.content, "Bienvenue sur notre Papayoo's party\n Il y a actuellement %d joueur(s) connectés\n", i + 1);
		if(send(csock[i], &buffer, sizeof(buffer) -1, 0) < 0) {
			perror("send()");
			exit(errno);
		}
		/* RECEPTION */
		if((n = recv(csock[i], &buffer, sizeof(buffer) - 1, 0)) < 0) {
			perror("recv()");
			exit(errno);
		}
		if((pseudos[i] = (message *) malloc(sizeof(buffer))) == NULL) {
			perror("malloc()");
			exit(errno);
		}
		pseudos[i] = &buffer;
		i++;
		printf("Tentative de connexion de : %s\n", buffer.content);
	}
	if (i == MAX_PLAYER){
		buffer.status = 500;
		sprintf(buffer.content, "La partie est pleine, vous ne pouvez plus la rejoindre !\n");
		if(send(csock[i], &buffer, sizeof(buffer) -1, 0) < 0) {
			perror("send()");
			exit(errno);
		}
	}
	buffer.status = 1;
	memset(buffer.content, 0, sizeof buffer.content);

	sprintf(buffer.content, "La partie commence. Il y a au moins %d joueurs.\n", i);
	for (int compteur = 0 ; compteur < i; compteur++)
	{
		if(send(csock[compteur], &buffer, sizeof(buffer) -1, 0) < 0) {
			perror("send()");
			exit(errno);
		}
		/* RECEPTION */
		if((n = recv(csock[compteur], &buffer, sizeof(buffer) - 1, 0)) < 0) {
			perror("recv()");
			exit(errno);
		}
		printf("Le joueur a répondu : %s\n", buffer.content);

	}
	if(csock[i] == INVALID_SOCKET) {
		perror("accept()");
		exit(errno);
	}
	closesocket(sock);
	for(i =0; i < MAX_PLAYER; i++) {
		closesocket(csock[i]);
	}
}







